
package Modelo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import Modelo.Conexion;

public class CargarComboBox {
    Conexion con= new Conexion();
    
    public void consultar_cuentas(JComboBox seleccion_cuenta){
        
        java.sql.Connection conectar = null;    
        PreparedStatement pst = null;
        ResultSet result = null;
        String SSQL = "SELECT nombre FROM PlanDeCuentas";
        try {
       
            //Establecemos conexión con la BD 
            conectar = con.ObtenerConexion();  
            //Preparamos la consulta SQL
            pst = conectar.prepareStatement(SSQL);
            //Ejecutamos la consulta
            result = pst.executeQuery();
   
            //LLenamos nuestro ComboBox
            seleccion_cuenta.addItem("Seleccione:");
   
            while(result.next()){
   
                    seleccion_cuenta.addItem(result.getString("nombre"));
   
                }
            } catch (SQLException e) {

                JOptionPane.showMessageDialog(null, e);
    
                }finally{

                    if(conectar!=null){
        
                        try {
        
                             conectar.close();
                             result.close();
            
                             conectar=null;
                             result=null;
            
                        } catch (SQLException ex) {
            
                            JOptionPane.showMessageDialog(null, ex);
        
                            }
    
                    }

            }
    

    }

        
}

   
    
    
    

