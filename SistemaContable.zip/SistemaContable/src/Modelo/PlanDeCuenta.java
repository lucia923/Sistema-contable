/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author lucia
 */
public class PlanDeCuenta {
    private String nombre;
    private int nro_cta;
    private int recibe_saldo;
    private String tipo;
    
    public PlanDeCuenta(String nombre, int nro_cta, int recibe_saldo, String tipo){
        this.nombre=nombre;
        this.nro_cta=nro_cta;
        this.recibe_saldo=recibe_saldo;
        this.tipo=tipo;
    }  

    public String getNombre() {
        return nombre;
    }

    public int getNro_cta() {
        return nro_cta;
    }

    public int isRecibe_saldo() {
        return recibe_saldo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNro_cta(int nro_cta) {
        this.nro_cta = nro_cta;
    }

    public void setRecibe_saldo(int recibe_saldo) {
        this.recibe_saldo = recibe_saldo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
