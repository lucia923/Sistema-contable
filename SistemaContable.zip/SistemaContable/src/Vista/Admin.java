package Vista;


import java.awt.Dimension;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lucia
 */
public class Admin extends javax.swing.JFrame {
    
    public static DefaultTableModel tabla;

    /**
     * Creates new form admin
     */
    public Admin() {
        initComponents();
        this.setResizable(false);
        this.setLocationRelativeTo(null);
    }

    Admin(PlanCuenta aThis, boolean b) {
        initComponents();
    }

   Admin(LibroMayor aThis, boolean b) {
        //To change body of generated methods, choose Tools | Templates.
    }

    Admin(AsientoContable aThis, boolean b) {
        initComponents();
    }

    Admin(AgregarCuenta aThis, boolean b) {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        Plan_cuenta = new javax.swing.JButton();
        LM = new javax.swing.JButton();
        LD = new javax.swing.JButton();
        Asiento_cont = new javax.swing.JButton();
        salirAdmin = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Inicio");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        jLabel1.setText("Bienvenid@ Admin ");

        Plan_cuenta.setText("Ver plan de cuentas ");
        Plan_cuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Plan_cuentaActionPerformed(evt);
            }
        });

        LM.setText("Libro Mayor");
        LM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LMActionPerformed(evt);
            }
        });

        LD.setText("Libro Diario");
        LD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LDActionPerformed(evt);
            }
        });

        Asiento_cont.setText("Registrar asiento contable ");
        Asiento_cont.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Asiento_contActionPerformed(evt);
            }
        });

        salirAdmin.setText("Salir");
        salirAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirAdminActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(132, 132, 132)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(LM, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Plan_cuenta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(LD, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Asiento_cont, javax.swing.GroupLayout.DEFAULT_SIZE, 172, Short.MAX_VALUE))))
                        .addGap(0, 134, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(salirAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1)
                .addGap(38, 38, 38)
                .addComponent(Plan_cuenta)
                .addGap(18, 18, 18)
                .addComponent(LM)
                .addGap(18, 18, 18)
                .addComponent(LD)
                .addGap(18, 18, 18)
                .addComponent(Asiento_cont)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addComponent(salirAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Plan_cuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Plan_cuentaActionPerformed
        // TODO add your handling code here:
        PlanCuenta pc =new PlanCuenta();
        pc.setVisible(true);
        pc.setLocationRelativeTo(null);
        pc.setPreferredSize(new Dimension(629, 580));
        pc.pack();
        pc.setResizable(false);
        this.setVisible(false);
      
    }//GEN-LAST:event_Plan_cuentaActionPerformed

    private void LMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LMActionPerformed
        // TODO add your handling code here:
        LibroMayor LM = new LibroMayor(this,false);
        LM.setVisible(true);
        LM.setLocationRelativeTo(null);
        LM.setPreferredSize(new Dimension(645, 630));
        LM.pack();
        LM.setResizable(false);
        this.setVisible(false);
    }//GEN-LAST:event_LMActionPerformed

    private void Asiento_contActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Asiento_contActionPerformed
        // TODO add your handling code here:
        AsientoContable ac=new AsientoContable(this,false);
        ac.setVisible(true);
        ac.setLocationRelativeTo(null);
        ac.setPreferredSize(new Dimension(882, 565));
        ac.pack();
        ac.setResizable(false);
        this.setVisible(false);
    }//GEN-LAST:event_Asiento_contActionPerformed

    private void LDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LDActionPerformed
        // TODO add your handling code here:
        LibroDiario LD = new LibroDiario(this,false);
        LD.setVisible(true);
        LD.setLocationRelativeTo(null);
        LD.setPreferredSize(new Dimension(720, 770));
        LD.pack();
        LD.setResizable(false);
        this.setVisible(false);
    }//GEN-LAST:event_LDActionPerformed

    private void salirAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirAdminActionPerformed
        Inicio in= new Inicio();
        in.setVisible(true);
        in.setResizable(false);
        this.setVisible(false);
    }//GEN-LAST:event_salirAdminActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Asiento_cont;
    private javax.swing.JButton LD;
    private javax.swing.JButton LM;
    private javax.swing.JButton Plan_cuenta;
    private javax.swing.JLabel jLabel1;
    public javax.swing.JButton salirAdmin;
    // End of variables declaration//GEN-END:variables
}
