
package SistContable;

import Vista.Inicio;

/**
 *
 * @author lucia
 */
public class SistContable {
    
    public static void main(String[] args){
        
        Inicio in= new Inicio();
        in.setVisible(true);
        
        
        
        
        
    } 
    
    
    
    
    
    
    
    
    
    
   
    
}
