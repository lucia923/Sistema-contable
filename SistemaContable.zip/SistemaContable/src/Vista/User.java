package Vista;
 
import java.awt.Dimension;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author lucia
 */
public class User extends javax.swing.JFrame {
    
    public static DefaultTableModel tabla;

    public User() {
        initComponents();
        this.setResizable(false);
        this.setLocationRelativeTo(null);
    }

    User(PlanCuenta_user aThis, boolean b) {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bienvenido = new javax.swing.JLabel();
        plancta = new javax.swing.JButton();
        LM = new javax.swing.JButton();
        LD = new javax.swing.JButton();
        SalirUser = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bienvenido.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        bienvenido.setText("Bienvenid@ User ");

        plancta.setText("Ver Plan de cuentas");
        plancta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                planctaActionPerformed(evt);
            }
        });

        LM.setText("Ver Libro mayor ");
        LM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LMActionPerformed(evt);
            }
        });

        LD.setText("Ver Libro diario");
        LD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LDActionPerformed(evt);
            }
        });

        SalirUser.setText("Salir");
        SalirUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirUserActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(bienvenido)
                        .addGap(0, 233, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(SalirUser, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(113, 113, 113)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(LD, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LM, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(plancta, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(bienvenido)
                .addGap(44, 44, 44)
                .addComponent(plancta)
                .addGap(18, 18, 18)
                .addComponent(LM)
                .addGap(18, 18, 18)
                .addComponent(LD)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 78, Short.MAX_VALUE)
                .addComponent(SalirUser, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void planctaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_planctaActionPerformed
        PlanCuenta_user pcu =new PlanCuenta_user(this,false);
        pcu.setVisible(true);
        pcu.setLocationRelativeTo(null);
        pcu.setPreferredSize(new Dimension(530, 580));
        pcu.pack();
        pcu.setResizable(false);
        this.setVisible(false);
    }//GEN-LAST:event_planctaActionPerformed

    private void LMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LMActionPerformed
        LibroMayor LM = new LibroMayor(this,false);
        LM.setVisible(true);
        LM.setLocationRelativeTo(null);
        LM.setPreferredSize(new Dimension(645, 630));
        LM.pack();
        LM.setResizable(false);
        this.setVisible(false);
    }//GEN-LAST:event_LMActionPerformed

    private void LDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LDActionPerformed
        LibroDiario LD = new LibroDiario(this,false);
        LD.setVisible(true);
        LD.setLocationRelativeTo(null);
        LD.setPreferredSize(new Dimension(720, 770));
        LD.pack();
        LD.setResizable(false);
        this.setVisible(false);
    }//GEN-LAST:event_LDActionPerformed

    private void SalirUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirUserActionPerformed
        Inicio in= new Inicio();
        in.setVisible(true);
        in.setResizable(false);
        this.setVisible(false);
    }//GEN-LAST:event_SalirUserActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(User.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new User().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton LD;
    public javax.swing.JButton LM;
    private javax.swing.JButton SalirUser;
    private javax.swing.JLabel bienvenido;
    public javax.swing.JButton plancta;
    // End of variables declaration//GEN-END:variables
}
