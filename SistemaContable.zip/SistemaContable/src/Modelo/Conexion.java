package Modelo;

import java.sql.*;


public class Conexion {
    public static Connection ObtenerConexion(){
        String url="jdbc:sqlserver://localhost:1433;"
                +"database=SistCont;"
                +"user=sa;"
                +"password=1234;";
        try {
           Connection con = DriverManager.getConnection(url);
            return con;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            return null;
        }
        
        
        
                
                
    } 

    public Connection getConexion() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public PreparedStatement PrepareStatement(String sql) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
}
