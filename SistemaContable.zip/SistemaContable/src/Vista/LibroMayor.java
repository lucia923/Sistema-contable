package Vista;

import Modelo.CargarComboBox;
import static Modelo.Conexion.ObtenerConexion;
import com.toedter.calendar.JDateChooser;
import java.awt.Dimension;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class LibroMayor extends javax.swing.JFrame {
    private JFrame vista_ant;
    CargarComboBox selec_cta = new CargarComboBox();
    static ResultSet res;
    DefaultTableModel tabla= new DefaultTableModel();
    
    public LibroMayor() {
        initComponents();
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        selec_cta.consultar_cuentas(cta);
        
        
    }
    
    public void IniciarTabla(){
        tabla.addColumn("Detalle");
        tabla.addColumn("Debe");
        tabla.addColumn("Haber");
        tabla.addColumn("Saldo");
        
        getjTable1().setModel(tabla);
        LibroMayor(tabla);
        
    }
    public void LibroMayor(DefaultTableModel modelo){
    // DefaultTableModel modelo= new DafaultTableModel(); 
    Connection con= ObtenerConexion(); 
     //res= (ResultSet) Conexion.ObtenerConexion();
     Statement st;
     
     try{
         String sql= "select fecha, detalle, cuenta, debe, haber from Asiento_contable";
         st= con.createStatement();
         ResultSet rs= st.executeQuery(sql);
         String [] dato= new String [4];
         while (rs.next()){
             //String s= rs.getString(1);
             dato[0]= rs.getString("detalle");
             dato[1]=rs.getString("debe");
             dato[2]=rs.getString("haber");
             dato[3]=rs.getString("saldo");
             modelo.addRow(dato);   
         }
         
     }catch (SQLException e) {
            System.out.println(e.toString());
    }   
 }

    public JFrame getVista_ant() {
        return vista_ant;
    }

    public void setVista_ant(JFrame vista_ant) {
        this.vista_ant = vista_ant;
    }

    public CargarComboBox getSelec_cta() {
        return selec_cta;
    }

    public void setSelec_cta(CargarComboBox selec_cta) {
        this.selec_cta = selec_cta;
    }

    public static ResultSet getRes() {
        return res;
    }

    public static void setRes(ResultSet res) {
        LibroMayor.res = res;
    }

    public DefaultTableModel getTabla() {
        return tabla;
    }

    public void setTabla(DefaultTableModel tabla) {
        this.tabla = tabla;
    }

    public JButton getAtras_admin() {
        return atras_admin;
    }

    public void setAtras_admin(JButton atras_admin) {
        this.atras_admin = atras_admin;
    }

    public JComboBox<String> getCta() {
        return cta;
    }

    public void setCta(JComboBox<String> cta) {
        this.cta = cta;
    }

    public JDateChooser getDesde() {
        return desde;
    }

    public void setDesde(JDateChooser desde) {
        this.desde = desde;
    }

    public JLabel getDesde_txt() {
        return desde_txt;
    }

    public void setDesde_txt(JLabel desde_txt) {
        this.desde_txt = desde_txt;
    }

    public JDateChooser getHasta() {
        return hasta;
    }

    public void setHasta(JDateChooser hasta) {
        this.hasta = hasta;
    }

    public JLabel getHasta_txt() {
        return hasta_txt;
    }

    public void setHasta_txt(JLabel hasta_txt) {
        this.hasta_txt = hasta_txt;
    }

    public JLabel getjLabel7() {
        return jLabel7;
    }

    public void setjLabel7(JLabel jLabel7) {
        this.jLabel7 = jLabel7;
    }

    public JLabel getjLabel9() {
        return jLabel9;
    }

    public void setjLabel9(JLabel jLabel9) {
        this.jLabel9 = jLabel9;
    }

    public JScrollPane getjScrollPane1() {
        return jScrollPane1;
    }

    public void setjScrollPane1(JScrollPane jScrollPane1) {
        this.jScrollPane1 = jScrollPane1;
    }

    public JTable getjTable1() {
        return jTable1;
    }

    public void setjTable1(JTable jTable1) {
        this.jTable1 = jTable1;
    }

    public JButton getLimp_filtro() {
        return limp_filtro;
    }

    public void setLimp_filtro(JButton limp_filtro) {
        this.limp_filtro = limp_filtro;
    }

    public JButton getVer_libroM() {
        return ver_libroM;
    }

    public void setVer_libroM(JButton ver_libroM) {
        this.ver_libroM = ver_libroM;
    }

    LibroMayor(Admin admin, boolean b) {
        this.vista_ant=admin;
        initComponents();
    }

    LibroMayor(User user, boolean b) {
        this.vista_ant=user;
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        atras_admin = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        desde_txt = new javax.swing.JLabel();
        hasta_txt = new javax.swing.JLabel();
        ver_libroM = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        cta = new javax.swing.JComboBox<>();
        desde = new com.toedter.calendar.JDateChooser();
        hasta = new com.toedter.calendar.JDateChooser();
        limp_filtro = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Libro Mayor");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Detalle", "Debe", "Haber", "Saldo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Float.class, java.lang.Float.class, java.lang.Float.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setMinWidth(305);
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(305);
            jTable1.getColumnModel().getColumn(0).setMaxWidth(305);
            jTable1.getColumnModel().getColumn(1).setMinWidth(80);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(80);
            jTable1.getColumnModel().getColumn(1).setMaxWidth(80);
            jTable1.getColumnModel().getColumn(2).setMinWidth(80);
            jTable1.getColumnModel().getColumn(2).setPreferredWidth(80);
            jTable1.getColumnModel().getColumn(2).setMaxWidth(80);
            jTable1.getColumnModel().getColumn(3).setMinWidth(80);
            jTable1.getColumnModel().getColumn(3).setPreferredWidth(80);
            jTable1.getColumnModel().getColumn(3).setMaxWidth(80);
        }

        atras_admin.setText("Atrás");
        atras_admin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atras_adminActionPerformed(evt);
            }
        });

        jLabel7.setText("Seleccione fecha para ver el asiento:");

        desde_txt.setText("Desde: ");

        hasta_txt.setText("Hasta:");

        ver_libroM.setText("Ver");
        ver_libroM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ver_libroMActionPerformed(evt);
            }
        });

        jLabel9.setText("Cuenta:");

        cta.setEditable(true);
        cta.setToolTipText("");

        limp_filtro.setText("Limpiar filtro");
        limp_filtro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limp_filtroActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 616, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cta, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel7)
                                    .addComponent(atras_admin, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(desde_txt)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(desde, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(hasta_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(hasta, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ver_libroM)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(limp_filtro, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(atras_admin)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(cta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(desde_txt)
                                    .addComponent(desde, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(ver_libroM)
                                        .addComponent(limp_filtro)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(hasta_txt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(12, 12, 12)))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(hasta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ver_libroMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ver_libroMActionPerformed
        if(desde.getCalendar()== null && hasta.getCalendar()== null &&
           cta.getSelectedItem().toString()== "Seleccione:"){
                JOptionPane.showMessageDialog(null,"Debe completar los campos vacíos");
            }else if(cta.getSelectedItem().toString()== "Seleccione:"){
                JOptionPane.showMessageDialog(null,"Debe seleccionar una empresa");
            }else if(hasta.getCalendar()== null){
                JOptionPane.showMessageDialog(null,"Debe agregar una fecha 'hasta'");
            }else if(desde.getCalendar()== null){
                JOptionPane.showMessageDialog(null,"Debe agregar una fecha 'desde'");
            }else{
                //ir a buscar la tabla a la BD y mostrarla
               IniciarTabla();
            }
    }//GEN-LAST:event_ver_libroMActionPerformed

    private void atras_adminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atras_adminActionPerformed
        this.vista_ant.setVisible(true);
        this.vista_ant.setLocationRelativeTo(null);
        this.vista_ant.setPreferredSize(new Dimension(450, 340));
        this.vista_ant.pack();
        this.vista_ant.setResizable(false);
        this.setVisible(false);
    }//GEN-LAST:event_atras_adminActionPerformed

    private void limp_filtroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limp_filtroActionPerformed
        desde.setCalendar(null);
        hasta.setCalendar(null);
        jTable1.setTableHeader(null);
        cta.setSelectedItem("Seleccione:");
    }//GEN-LAST:event_limp_filtroActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LibroMayor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LibroMayor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LibroMayor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LibroMayor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LibroMayor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton atras_admin;
    public javax.swing.JComboBox<String> cta;
    public com.toedter.calendar.JDateChooser desde;
    public javax.swing.JLabel desde_txt;
    public com.toedter.calendar.JDateChooser hasta;
    public javax.swing.JLabel hasta_txt;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    public javax.swing.JButton limp_filtro;
    public javax.swing.JButton ver_libroM;
    // End of variables declaration//GEN-END:variables
}
