package Modelo;

import static Modelo.Conexion.ObtenerConexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class prueba {
    static ResultSet res;
    private Conexion conexion= new Conexion();
    public prueba() {
        cargarPlanCuenta();
        System.out.println("hola");
    }
     public static void main(String[] args) {
        Connection con= ObtenerConexion(); 
     //res= (ResultSet) Conexion.ObtenerConexion();
     Statement st;
     
     try{
         String sql= "select * from PlanDeCuentas";
         st= con.createStatement();
        
         ResultSet rs= st.executeQuery(sql);
         
         while (res.next()){
             String s= rs.getString(1);
             System.out.println("datos extraídos:"+ s);
         }     
     }catch (SQLException e) {
            System.out.println(e.toString());
     }

    }
     public void cargarPlanCuenta(){
    // DefaultTableModel modelo= new DafaultTableModel(); 
    Connection con= ObtenerConexion(); 
     //res= (ResultSet) Conexion.ObtenerConexion();
     Statement st;
     
     try{
         String sql= "select * from PlanDeCuentas";
         st= con.createStatement();
         ResultSet rs= st.executeQuery(sql);
         
         while (res.next()){
             String s= rs.getString(1);
             System.out.println("datos extraídos:"+ s);   
         }   
     }catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
}
