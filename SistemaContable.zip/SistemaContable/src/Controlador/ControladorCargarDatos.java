//Cargamos los datos del asiento contable 

package Controlador;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.*;
import Modelo.Conexion;

public class ControladorCargarDatos {
    
    private Conexion con;
    private ControladorAsientoC modelo;
    private Connection cxn;

    public ControladorCargarDatos() {
        con = new Conexion();
        modelo = new ControladorAsientoC();    
    }
    public void insertar(Date fecha, String detalle, String cuenta, float debe, float haber){
        PreparedStatement ps;
        String sql;
        modelo.setFecha(fecha);
        modelo.setDetalle(detalle);
        modelo.setCuenta(cuenta);
        modelo.setDebe(debe);
        modelo.setHaber(haber);
        try {
            cxn = con.getConexion();
            sql = "insert into Asiento_contable(fecha, detalle, cuenta, debe, haber) values(?,?,?,?,?)";
            ps = con.PrepareStatement(sql);
            ps.setDate(1, modelo.getFecha());
            ps.setString(2, modelo.getDetalle());            
            ps.setString(3, modelo.getCuenta());
            ps.setFloat(4, modelo.getDebe());
            ps.setFloat(5, modelo.getHaber());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "Se han insertado los datos");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de conexión:" + e.getMessage());
        }
            
        }
    }
    
    
    
    
    
    
    
    
    

