package Vista;

import Modelo.CargarComboBox;
import Modelo.Conexion;
import static Modelo.Conexion.ObtenerConexion;
import com.toedter.calendar.JDateChooser;
import java.awt.Dimension;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class LibroDiario extends javax.swing.JFrame {
    private JFrame vista_ant;
    CargarComboBox selec_cta = new CargarComboBox();
    static ResultSet res;
    DefaultTableModel tabla= new DefaultTableModel();
    
    public LibroDiario() {
        initComponents();
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        selec_cta.consultar_cuentas(cuenta);
    }
    public void IniciarTabla(){
        tabla.addColumn("Detalle");
        tabla.addColumn("Debe");
        tabla.addColumn("Haber");
        tabla.addColumn("Saldo");
        
        getjTable1().setModel(tabla);
        LibroDiario(tabla);
        
    }
    public void LibroDiario(DefaultTableModel modelo){
    // DefaultTableModel modelo= new DafaultTableModel(); 
    Connection con= ObtenerConexion(); 
     //res= (ResultSet) Conexion.ObtenerConexion();
     PreparedStatement st;
     
     try{
         String sql= "select fecha, detalle, cuenta, debe, haber from Asiento_contable where fecha between ? and ?";
         st= con.prepareStatement(sql);
         st.setDate(1, (Date) desde.getDate());
         st.setDate(2, (Date) hasta.getDate());
         ResultSet rs= st.executeQuery();
         String [] dato= new String [5];
         while (rs.next()){
             //String s= rs.getString(1);
             dato[0]= rs.getString("fecha");
             dato[1]=rs.getString("detalle");
             dato[2]=rs.getString("cuenta");
             dato[3]=rs.getString("debe");
             dato[4]=rs.getString("haber");
             modelo.addRow(dato);  
             //jTable1.setModel(modelo);
         }
         //jTable1.setModel(modelo);
     }catch (SQLException e) {
            System.out.println(e.toString());
    }   
 }

    public JFrame getVista_ant() {
        return vista_ant;
    }

    public void setVista_ant(JFrame vista_ant) {
        this.vista_ant = vista_ant;
    }

    public CargarComboBox getSelec_cta() {
        return selec_cta;
    }

    public void setSelec_cta(CargarComboBox selec_cta) {
        this.selec_cta = selec_cta;
    }

    public static ResultSet getRes() {
        return res;
    }

    public static void setRes(ResultSet res) {
        LibroDiario.res = res;
    }

    public DefaultTableModel getTabla() {
        return tabla;
    }

    public void setTabla(DefaultTableModel tabla) {
        this.tabla = tabla;
    }

    public JButton getVer_LD() {
        return Ver_LD;
    }

    public void setVer_LD(JButton Ver_LD) {
        this.Ver_LD = Ver_LD;
    }

    public JButton getAtrás_Ld() {
        return atrás_Ld;
    }

    public void setAtrás_Ld(JButton atrás_Ld) {
        this.atrás_Ld = atrás_Ld;
    }

    public JButton getClear() {
        return clear;
    }

    public void setClear(JButton clear) {
        this.clear = clear;
    }

    public JComboBox<String> getCuenta() {
        return cuenta;
    }

    public void setCuenta(JComboBox<String> cuenta) {
        this.cuenta = cuenta;
    }

    public JDateChooser getDesde() {
        return desde;
    }

    public void setDesde(JDateChooser desde) {
        this.desde = desde;
    }

    public JDateChooser getHasta() {
        return hasta;
    }

    public void setHasta(JDateChooser hasta) {
        this.hasta = hasta;
    }

    public JButton getjButton1() {
        return jButton1;
    }

    public void setjButton1(JButton jButton1) {
        this.jButton1 = jButton1;
    }

    public JLabel getjLabel1() {
        return jLabel1;
    }

    public void setjLabel1(JLabel jLabel1) {
        this.jLabel1 = jLabel1;
    }

    public JLabel getjLabel2() {
        return jLabel2;
    }

    public void setjLabel2(JLabel jLabel2) {
        this.jLabel2 = jLabel2;
    }

    public JLabel getjLabel3() {
        return jLabel3;
    }

    public void setjLabel3(JLabel jLabel3) {
        this.jLabel3 = jLabel3;
    }

    public JLabel getjLabel4() {
        return jLabel4;
    }

    public void setjLabel4(JLabel jLabel4) {
        this.jLabel4 = jLabel4;
    }

    public JScrollPane getjScrollPane1() {
        return jScrollPane1;
    }

    public void setjScrollPane1(JScrollPane jScrollPane1) {
        this.jScrollPane1 = jScrollPane1;
    }

    public JTable getjTable1() {
        return jTable1;
    }

    public void setjTable1(JTable jTable1) {
        this.jTable1 = jTable1;
    }

    LibroDiario(Admin admin, boolean b) {
       this.vista_ant=admin;
       initComponents();
    }

    LibroDiario(User user, boolean b) {
       this.vista_ant=user; 
       initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        atrás_Ld = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        cuenta = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Ver_LD = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        desde = new com.toedter.calendar.JDateChooser();
        hasta = new com.toedter.calendar.JDateChooser();

        jButton1.setText("Registrar libro diario");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Libro diario");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Fecha", "Detalle", "Cuenta", "Debe", "Haber"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setMinWidth(80);
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(80);
            jTable1.getColumnModel().getColumn(0).setMaxWidth(80);
            jTable1.getColumnModel().getColumn(1).setMinWidth(210);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(210);
            jTable1.getColumnModel().getColumn(1).setMaxWidth(210);
            jTable1.getColumnModel().getColumn(2).setMinWidth(200);
            jTable1.getColumnModel().getColumn(2).setPreferredWidth(200);
            jTable1.getColumnModel().getColumn(2).setMaxWidth(200);
            jTable1.getColumnModel().getColumn(3).setMinWidth(80);
            jTable1.getColumnModel().getColumn(3).setPreferredWidth(80);
            jTable1.getColumnModel().getColumn(3).setMaxWidth(80);
            jTable1.getColumnModel().getColumn(4).setMinWidth(80);
            jTable1.getColumnModel().getColumn(4).setPreferredWidth(80);
            jTable1.getColumnModel().getColumn(4).setMaxWidth(80);
        }

        atrás_Ld.setText("Atrás");
        atrás_Ld.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                atrás_LdActionPerformed(evt);
            }
        });

        jLabel1.setText("Cuenta:");

        cuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cuentaActionPerformed(evt);
            }
        });

        jLabel2.setText("Seleccione fecha para ver el asiento:");

        jLabel3.setText("Desde:");

        jLabel4.setText("Hasta:");

        Ver_LD.setText("Ver");
        Ver_LD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ver_LDActionPerformed(evt);
            }
        });

        clear.setText("Limpiar filtro");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(hasta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(desde, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Ver_LD)
                .addGap(18, 18, 18)
                .addComponent(clear, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(327, 327, 327))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(atrás_Ld, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 669, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(19, 19, 19))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(atrás_Ld)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cuenta, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(desde, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(hasta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Ver_LD)
                            .addComponent(clear))))
                .addGap(14, 14, 14)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void atrás_LdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_atrás_LdActionPerformed
        this.vista_ant.setVisible(true);
        this.vista_ant.setLocationRelativeTo(null);
        this.vista_ant.setPreferredSize(new Dimension(450, 340));
        this.vista_ant.pack();
        this.setVisible(false);
    
    }//GEN-LAST:event_atrás_LdActionPerformed

    private void Ver_LDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ver_LDActionPerformed
        if(desde.getCalendar()== null && hasta.getCalendar()== null &&
           cuenta.getSelectedItem().toString()== "Seleccione:"){
                JOptionPane.showMessageDialog(null,"Debe completar los campos vacíos");
            }else if(cuenta.getSelectedItem().toString()== "Seleccione"){
                JOptionPane.showMessageDialog(null,"Debe seleccionar una empresa");
            }else if(hasta.getCalendar()== null){
                JOptionPane.showMessageDialog(null,"Debe agregar una fecha 'hasta'");
            }else if(desde.getCalendar()== null){
                JOptionPane.showMessageDialog(null,"Debe agregar una fecha 'desde'");
            }else{
                //ir a buscar la tabla a la BD y mostrarla
                IniciarTabla();
                //LibroDiario(tabla);
            }
    }//GEN-LAST:event_Ver_LDActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        desde.setCalendar(null);
        hasta.setCalendar(null);
        jTable1.setTableHeader(null);
        cuenta.setSelectedItem("Seleccione");
    }//GEN-LAST:event_clearActionPerformed

    private void cuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cuentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cuentaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LibroDiario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LibroDiario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LibroDiario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LibroDiario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LibroDiario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Ver_LD;
    private javax.swing.JButton atrás_Ld;
    public javax.swing.JButton clear;
    private javax.swing.JComboBox<String> cuenta;
    private com.toedter.calendar.JDateChooser desde;
    private com.toedter.calendar.JDateChooser hasta;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
