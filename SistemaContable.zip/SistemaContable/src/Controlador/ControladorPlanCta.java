/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import javax.swing.table.DefaultTableModel;
import Modelo.Conexion;
import Vista.PlanCuenta;




public class ControladorPlanCta {
    private DefaultTableModel tabla= new DefaultTableModel();
    private Conexion conexion=new Conexion();
    private PlanCuenta plan;

    public ControladorPlanCta(PlanCuenta plan) {
        this.plan = plan;
        IniciarTabla();
    }
    
    public void IniciarTabla(){
        tabla= new DefaultTableModel();
        tabla.addColumn("Nombre");
        tabla.addColumn("Numero de cuenta");
        tabla.addColumn("Recibe saldo");
        tabla.addColumn("Tipo");
        
        plan.getTablaPCta().setModel(tabla);
        
    }
    
    
    
    
    
}
